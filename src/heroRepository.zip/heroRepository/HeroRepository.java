package heroRepository;

public class HeroRepository {
    private Hero data;

    public HeroRepository() {
        this.data = data;
    }
}
