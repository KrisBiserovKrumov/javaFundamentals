package CustomListGernerics;

public class Main {
    private static final Engine ENGINE = new Engine();
    public static void main(String[] args) {
        ENGINE.run();


    }
}
